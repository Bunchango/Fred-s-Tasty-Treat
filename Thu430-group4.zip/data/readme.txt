coins.dat & foods.dat contains meals and coins in correct formats
incorrect_coins.dat & incorrect_foods.dat contains meals and coins in incorrect formats
no_coins.dat & no_foods.dat contains no meals and coins
