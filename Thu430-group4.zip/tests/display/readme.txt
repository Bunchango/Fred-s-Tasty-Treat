Files with correct in its name is tested using data with correct format 
While files with incorrect in its name is tested using incorrect format data
